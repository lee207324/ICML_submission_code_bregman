function C=vec(M);

C=M(:);